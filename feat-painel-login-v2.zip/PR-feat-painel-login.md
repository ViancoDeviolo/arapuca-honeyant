# feat(painel): login do operador

Revisores: Lucas (encaixe e `apps/`) e Kawe (olhar externo de segurança).

## O quê
Autenticação do painel, encaixada pelo `Encaixe` do Lucas (`protecao_api`, `protecao_pagina`, `routers`). Sem dependência nova.

- `painel/autenticacao.py`: hash `scrypt`, bloqueio por tentativas, sessões, as duas proteções e o router do login.
- `painel/login/login.{html,css,js}`: tela de login (tema escuro, foco visível, só teclado), sem script nem estilo inline.
- `apps/painel_login.py`: `encaixe_do_ambiente()`. `apps/hash_senha.py`: comando `honeyant-hash-senha`.
- `apps/local.py`: uma linha no `main()`. `pyproject.toml`: uma linha em `[project.scripts]`.

## Como gerar o hash e configurar
```powershell
uv run honeyant-hash-senha
$env:HONEYANT_PAINEL_SENHA_HASH = '<o hash impresso>'
uv run honeyant-local
```
- Sem `HONEYANT_PAINEL_SENHA_HASH`, o painel abre sem login, como hoje, preso ao loopback.
- Com um hash inválido, o painel não sobe (`ValueError` com mensagem clara, sem repetir o valor).
- `HONEYANT_PAINEL_COOKIE_SEGURO=0` só existe para um navegador que recuse o cookie `Secure` em `http://127.0.0.1`.
- O hash vai para o `.env` local (no `.gitignore`). Nenhuma senha ou hash real entra em teste, exemplo ou log.

## Bloqueio na demo (leia antes de apresentar)
- 5 falhas dentro de 15 min bloqueiam o IP por 15 min. Na demo todo acesso vem de `127.0.0.1`, então **errar 5 vezes bloqueia o próprio apresentador**.
- A tela de bloqueio diz quanto falta: "Muitas tentativas. Tente de novo em N min."
- O bloqueio fica só em memória: **reiniciar o processo (`honeyant-local`) o limpa**. Reiniciar também derruba as sessões.
- Durante o bloqueio a senha nem é verificada (429 direto).

## Decisões de segurança
- Hash `scrypt$16384$8$1$<sal_b64>$<hash_b64>`, sal de 16 bytes. Recusa `n` acima de `2**17` e hash malformado (`False`, sem exceção). Comparação com `hmac.compare_digest`.
- Sessão com `secrets.token_urlsafe(32)`, 8 h; o servidor guarda só o SHA-256 do token. Cookie `HttpOnly`, `Secure`, `SameSite=Strict`, `Path=/`, `Max-Age=28800`.
- CSRF de login: `Origin` presente e fora de loopback dá 403 (compara o host, ignora a porta). Vale também para o logout.
- Corpo do `POST /login` limitado a 4 KB (413), lido por stream. Sem `python-multipart`.
- A checagem de bloqueio, a verificação e a contagem de falha acontecem sem `await` entre elas, então requisições simultâneas não furam o limite. O custo é ~50 ms de loop por tentativa.
- IP vem de `request.client.host` (sem proxy, sem `X-Forwarded-For`). Teto de 4096 IPs e 32 sessões em memória.
- Log só registra "falha de login": nunca senha, token, cookie nem hash.

## Testes
68 testes novos (unitários com relógio injetado, sem `sleep`; segurança 1 a 8 da orientação; comando de hash; encaixe do ambiente). `ruff`, `ruff format --check`, `lint-imports` e `bandit` sem achados.

## Conferência no navegador
Feita num Chromium de automação, com servidor real em `http://127.0.0.1`: sem sessão redireciona para `/login`; senha errada mostra "Senha incorreta."; senha certa entra; cookie `Secure`, `HttpOnly` e `Strict` foi aceito; a API responde 200 com o cookie; depois do logout a página volta para `/login`. Tudo só pelo teclado.
**Refazer no navegador da apresentação** (preencher aqui): ______ . Se ele recusar o `Secure`, anotar e testar com `HONEYANT_PAINEL_COOKIE_SEGURO=0`; o Lucas decide.

## Dívida técnica
- Bloqueios e sessões em memória (reiniciar limpa o bloqueio e derruba as sessões).
- Um flood de IPs distintos pode empurrar os IPs mais antigos para fora do limitador (teto).
- Um único usuário e uma única senha; trocar a senha exige gerar outro hash e reiniciar.
- Sem TLS próprio e sem `HONEYANT_MODO`: abrir o painel para fora do loopback é decisão do Lucas.
