# Login do painel (v2, seguindo a orientação nova)

Esta versão **substitui** o `feat-painel-login.zip` anterior. Ela segue `orientacao-login-gustavo.md`: `Encaixe`, hash `scrypt$...`, campo único `senha`, formulário HTML puro e a pasta `painel/login/`. Não misture com os arquivos da versão anterior.

## Pendente (preciso da branch do Lucas)
O `Encaixe` e o `montar(config, encaixe=...)` estão na branch `feat/painel-encaixe`, que não estava no zip que recebi. Por isso:
1. `apps/painel_login.py` foi verificado com um stub idêntico à definição da orientação. **Confirme na sua branch real** que `from honeyant.painel.app import Encaixe` funciona.
2. **Não escrevi** o teste de fluxo completo com `montar(config, encaixe=...)` (seção 4 da orientação). Se me enviar o zip da branch `feat/painel-encaixe`, eu escrevo e verifico.
3. A **uma linha do `apps/local.py`** você aplica à mão (seção 6 da orientação).

## Passo a passo (PowerShell)
```powershell
git fetch origin
git switch -c feat/painel-login origin/feat/painel-encaixe

# 1. copie o conteúdo da pasta arquivos\ por cima da raiz do repositório
Copy-Item -Recurse -Force C:\caminho\da\entrega\arquivos\* .

# 2. pyproject.toml, [project.scripts]: acrescente UMA linha (ou: git apply ...\pyproject.patch)
#    honeyant-hash-senha = "honeyant.apps.hash_senha:main"

# 3. apps\local.py: o import no topo do arquivo e, no main(), troque
#    uvicorn.run(montar(config), host=config.host, port=config.porta)
#    por
#    uvicorn.run(montar(config, encaixe=encaixe_do_ambiente()), host=config.host, port=config.porta)
#    import: from honeyant.apps.painel_login import encaixe_do_ambiente

# 4. confira o que o CI confere
uv run ruff check .
uv run ruff format --check .
uv run lint-imports
uv run bandit -q -c pyproject.toml -r src
uv run pytest -m "not integration" -q

# 5. commits pequenos, adicionando cada arquivo pelo nome (nunca git add .)
git add src/honeyant/painel/autenticacao.py tests/unit/painel/test_autenticacao.py
git commit -m "feat(painel): hash, bloqueio, sessões e proteções do login"
git add src/honeyant/painel/login/login.html src/honeyant/painel/login/login.css src/honeyant/painel/login/login.js tests/security/test_login.py
git commit -m "feat(painel): tela e rotas de login com testes de segurança"
git add src/honeyant/apps/hash_senha.py tests/unit/apps/test_hash_senha.py pyproject.toml
git commit -m "feat(apps): comando honeyant-hash-senha"
git add src/honeyant/apps/painel_login.py tests/unit/apps/test_painel_login.py src/honeyant/apps/local.py
git commit -m "feat(apps): encaixe do login no painel local"
git push -u origin feat/painel-login
```
Não faça commit de `uv.lock`, `__pycache__`, `*.egg-info` nem `.venv`. Nenhum commit leva `Co-Authored-By`.

## Uso (para o PR)
```powershell
uv run honeyant-hash-senha
$env:HONEYANT_PAINEL_SENHA_HASH = '<o hash impresso>'   # aspas simples: o hash tem "$"
uv run honeyant-local
```

## Falha antiga que não é do login
`test_verificar_ro.py::test_main_imprime_json_sem_ip_e_sai_com_zero` falha onde o usuário é root (o `chmod 444` não vale). No seu computador deve passar.
